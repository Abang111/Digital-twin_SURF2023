@echo off
REM ===========================================================
REM deploy_follower.bat
REM 将 follower_vehicle.py 覆写到 Webots 控制器目录，并打开指定的 .wbt 场景
REM 请右键此脚本，选择“以管理员身份运行”
REM ===========================================================

REM 源文件与目标目录/文件
SET "src=C:\Users\17994\Desktop\projects1\vehicles\controllers\follower_vehicle\follower_vehicle.py"
SET "dstDir=C:\Program Files\Webots\projects\vehicles\controllers\follower_vehicle"
SET "dstFile=%dstDir%\follower_vehicle.py"

REM 场景文件
SET "wbtFile=C:\Users\17994\Desktop\V11\map2.wbt"

REM 创建目标目录（如果不存在）
IF NOT EXIST "%dstDir%" (
    mkdir "%dstDir%"
    IF ERRORLEVEL 1 (
        echo [错误] 无法创建目录 %dstDir%。请检查管理员权限。
        pause
        exit /b 1
    )
)

REM 复制并覆盖
copy /Y "%src%" "%dstFile%"
IF ERRORLEVEL 1 (
    echo [错误] 无法复制文件到 %dstFile%。请检查源文件路径及管理员权限。
    pause
    exit /b 1
) ELSE (
    echo [成功] 已将 "%src%" 覆写到 "%dstFile%"
)

REM 打开 .wbt 场景（默认用 Webots 打开）
start "" "%wbtFile%"
IF ERRORLEVEL 1 (
    echo [警告] 打开场景文件失败，请检查 %wbtFile% 是否存在，并确认已安装 Webots。
) ELSE (
    echo [已打开] 场景文件：%wbtFile%
)

exit /b 0
